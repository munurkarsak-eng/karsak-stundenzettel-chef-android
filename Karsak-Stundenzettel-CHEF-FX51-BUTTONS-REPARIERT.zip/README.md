Karsak Stundenzettel CHEF FX46

Basis: FX45.

Neu:
- Mittleres Dachdecker-Karsak-Wappen = Chef-Supabase-Anmeldung / Stunden aktualisieren.
- Einmalige E-Mail-/Passwort-Anmeldung; Refresh-Token hält die Anmeldung dauerhaft auf diesem Gerät aktiv, bis bewusst abgemeldet wird.
- Ablehnungs-/Änderungsgrund wird in Monatsansicht und PDF mit Datum und betroffenen Stunden ausgegeben.
- Keine Sollstunden / keine automatische Plus-Minus-Berechnung.
