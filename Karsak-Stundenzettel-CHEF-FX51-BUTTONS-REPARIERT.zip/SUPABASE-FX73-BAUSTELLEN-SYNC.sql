-- FX48 / FX73: vollständige Baustellenliste zwischen Chef- und Mitarbeiter-App synchronisieren

CREATE TABLE IF NOT EXISTS public.construction_sites (
  site_key text PRIMARY KEY,
  name text NOT NULL,
  active boolean NOT NULL DEFAULT true,
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.construction_sites ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS construction_sites_select_authenticated ON public.construction_sites;
DROP POLICY IF EXISTS construction_sites_insert_authenticated ON public.construction_sites;
DROP POLICY IF EXISTS construction_sites_update_authenticated ON public.construction_sites;
DROP POLICY IF EXISTS construction_sites_delete_authenticated ON public.construction_sites;

CREATE POLICY construction_sites_select_authenticated
ON public.construction_sites
FOR SELECT TO authenticated
USING (true);

CREATE POLICY construction_sites_insert_authenticated
ON public.construction_sites
FOR INSERT TO authenticated
WITH CHECK (true);

CREATE POLICY construction_sites_update_authenticated
ON public.construction_sites
FOR UPDATE TO authenticated
USING (true)
WITH CHECK (true);

CREATE POLICY construction_sites_delete_authenticated
ON public.construction_sites
FOR DELETE TO authenticated
USING (true);
