# Karsak Stundenzettel FIX1
Android-App für Arbeitszeiten und Baustellen mit Sprachassistent.

## Sprachablauf
Chef: Mitarbeiter -> Beginn -> Feierabend -> Baustelle/Projekt -> Tätigkeit -> Zusammenfassung -> Speichern.
Mitarbeiter: Beginn -> Feierabend -> Baustelle/Projekt -> Tätigkeit -> Zusammenfassung -> Speichern.

Die vorhandene Trennung bleibt erhalten: Mitarbeiter sehen ihre eigenen Zeiten; Stundenlöhne/Vorschüsse liegen im Chefbereich.

## APK bauen
Projekt in GitHub hochladen und unter Actions `Android APK bauen` starten. Das Ergebnis heißt `Karsak-Stundenzettel-APK`.


## FIX4
Datumserfassung nach Mitarbeiter, schnelle Satzanalyse und Monatsübersicht Januar–Dezember ergänzt.


## FIX5
Startseite mit vier getrennten Bereichen: Mitarbeiter, Sprachassistent, Zahlungen und Neuer Mitarbeiter. Mitarbeiteransicht enthält nur Mitarbeiter-Namen und Monatsübersicht.

FX9: Sprachwahl per Zahl/Wort, Safe-Area für Bearbeiten/Speichern, Chef-Kacheln Stundenzettel/PDF.

## FX11
- Sprachassistent: Mitarbeiterauswahl per Name oder Nummer robuster.
- Akzeptiert z. B. „eins“, „1“, „Nummer eins“, „Mitarbeiter eins“, „zwei“, „2“ usw.
- Nummernauswahl wird direkt übernommen, ohne die Mitarbeiterfrage erneut zu stellen.


## FX16
- Stundenlohn wird bei jedem Zeiteintrag fest gespeichert (rateAtEntry).
- Spätere Änderungen des Mitarbeiter-Stundenlohns verändern alte Einsätze nicht mehr.
- Im Chefbereich kann der Lohnsatz eines einzelnen alten Einsatzes über 'Lohnsatz' korrigiert werden.
- PDF, Mitarbeiterübersicht und Baustellen-Lohnkosten verwenden den historischen Lohnsatz des jeweiligen Einsatzes.

FX17: Zuletzt gewählter Mitarbeiter bei manueller Zeiterfassung wird dauerhaft gemerkt.


## FX19
- Ein zentraler Startseitenpunkt „Zahlungen“.
- Zweite Auswahl: Mitarbeiter oder Projekt.
- Mitarbeiter: Vorschüsse/Lohnauszahlungen.
- Projekt: Kundenzahlungen, Sonderabmachungen/Nachträge sowie Material-/Rechnungszahlungen in einer Ansicht.
- Kundenzahlungen bleiben vom Gewinn getrennt; Projektausgaben fließen als Kosten ein.

## FX20
- Login neu: Chef zuerst, Mitarbeiter als direkter Auswahlpunkt; nach Mitarbeiterwahl erscheint sofort die Code-Eingabe.
- Chef-Startseite kompakter.
- Zahlungen: Mitarbeiter/Projekt als klare Unterauswahl.
- Mitarbeiterzahlungen: Mitarbeiterliste zuerst; Zahnrad für Bearbeiten oder Neuanlage.
- PDF: nur noch ein Startpunkt; danach Senden oder Speichern.
- PDF-Senden: native Android-Freigabe als PDF ergänzt.
- Projekte: Untermenü Auftrag anlegen / Aufträge.

## FX21 – Wasser/Glas-Design
- Komplett neues Chef-Dashboard im Wasser-/Glas-Look.
- Runde, transparente Wappen statt eckiger Kacheln.
- Dachdecker-Karsak-Wasserzeichen im Hintergrund.
- Kompakter Marken-Kopf mit Assistenten-Wappen.
- Bestehende Funktionen aus FX20 bleiben erhalten.


## FX25
- Neu sauber von FX21 aufgebaut.
- Kein Einfügen mehr mitten in eine PDF-HTML-Vorlage: sichtbarer JavaScript-Text unten beseitigt.
- Einheitlich kleinere transparente Rundbuttons.
- Mitarbeiter: nur ein zentrales Zahnrad, keine Bearbeiten/Löschen-Schaltflächen pro Person.
- Gesprächsaufnahme läuft nativ über Android MediaRecorder und funktioniert nicht mehr über file:// getUserMedia.
- Problematischen nativen PDF-FileProvider-Block entfernt; Druck/PDF bleibt über Android-Druckdialog.


## FX26
- Sichtbaren JavaScript-Text am unteren Bildschirmrand vollständig repariert.
- Ursache war ein alter FX20/FX21-Block innerhalb der FX9-PDF-Druckvorlage.
- Mitarbeiter öffnet jetzt direkt ein gläsernes Wassertropfen-Popup.
- Mitarbeiter-Namen groß und deutlich lesbar.
- Nur eine zentrale Mitarbeiterverwaltung.
- Gesprächsseite oben mit sauberem Abstand unter der Kopfzeile.
- Startseite mit transparenten Glas-/Wassertropfen-Schaltflächen.


## FX27
- Mitarbeiternamen in Verwaltung/Bearbeitung auf weißem Hintergrund schwarz dargestellt.
- Eingabefelder in der Mitarbeiterverwaltung ebenfalls mit schwarzer Schrift.
- Alle Funktionen aus FX26 unverändert übernommen.


## FX28
- Sprachassistent wieder als einzelner gläserner Mikrofon-Button eingeblendet.
- Vorhandene Sprachlogik bleibt erhalten.
- Ganze Sätze mit Mitarbeiter, von/bis-Zeit und gespeicherter Baustelle werden verarbeitet.
- Beispiel: „Kerim hat von 7 bis 18 Uhr in Hannover gearbeitet.“
- Mitarbeiter-/Wassertropfen-Design und alle FX27-Funktionen unverändert übernommen.


## Chef-App FX29
- Bereich "Offene Stunden" ergänzt.
- Lädt Mitarbeiterstunden aus Firestore `pending_hours`.
- Chef kann bestätigen, Zeiten ändern oder ablehnen.
- REST-basierte Firebase-Anbindung ohne zusätzliche Firebase-Gradle-Bibliotheken.

FX30: Firebase-Cloudteil durch Supabase ersetzt. Chef-Anmeldung per E-Mail/Passwort. Siehe SUPABASE-CHEF-FX30.sql.


## Chef-App FX32
- Bestätigte (`approved`) und vom Chef geänderte (`changed`) Supabase-Stunden werden automatisch in den lokalen Mitarbeiter-Kalender übernommen.
- Finale Chef-Zeiten (`chef_start` / `chef_end`) werden dabei verwendet.
- Abgelehnte Stunden (`rejected`) werden nicht als Arbeitsstunden gezählt.
- Zuordnung erfolgt über `employee_name`; ältere Datensätze ohne Namen bleiben unzugeordnet statt einem falschen Mitarbeiter zugeschlagen zu werden.
- Supabase-Datensätze werden anhand ihrer Cloud-ID aktualisiert, nicht doppelt angelegt.
