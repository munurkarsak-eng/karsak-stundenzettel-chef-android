-- CHEF-FX31: einmal im Supabase SQL Editor ausführen
alter table public.work_entries add column if not exists status text default 'pending';
alter table public.work_entries add column if not exists chef_start time;
alter table public.work_entries add column if not exists chef_end time;

drop policy if exists "chef_select_all_work_entries" on public.work_entries;
create policy "chef_select_all_work_entries" on public.work_entries
for select to authenticated
using (coalesce((auth.jwt()->>'is_anonymous')::boolean, false) = false);

drop policy if exists "chef_update_all_work_entries" on public.work_entries;
create policy "chef_update_all_work_entries" on public.work_entries
for update to authenticated
using (coalesce((auth.jwt()->>'is_anonymous')::boolean, false) = false)
with check (coalesce((auth.jwt()->>'is_anonymous')::boolean, false) = false);
