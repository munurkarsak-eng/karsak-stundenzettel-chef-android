Karsak Stundenzettel CHEF FX45

Basis: FX44.
Wichtigster Fix: keine Sollstunden, keine pauschalen Minusstunden. Abgelehnte Stunden werden separat ausgewiesen; vom Chef geänderte Stunden zeigen nur die tatsächliche Differenz.
