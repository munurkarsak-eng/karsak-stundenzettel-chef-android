# Karsak Stundenzettel CHEF FX42

Basis: FX41 Anzeige-Fix + Bearbeiten gespeicherter Mitarbeiter-/Lohnzahlungen.

## FX42 Abrechnungslogik
- Keine Sollstunden oder Pflichtstunden.
- Monatslohn wird ausschließlich aus vom Chef bestätigten/geänderten Stunden berechnet.
- Mitarbeiter-Eingabe bleibt als Original erhalten.
- Bei Chef-Änderung wird nur die echte Differenz als Korrektur angezeigt.
- Abgelehnte Tage erscheinen rot als „Nicht bestätigt / gelöscht“ und werden mit 0 Stunden/0 Euro abgerechnet.
- PDF zeigt eingereichte Zeit, abgerechnete Zeit, Korrektur und abgelehnte Tage.
- Assistent-Dock wird beim PDF-Druck ausgeblendet.
- Gespeicherte Lohnzahlungen bleiben bearbeitbar und löschbar.

FX44: Chef-Startseite als geliefertes Bilddesign mit klickbaren Hotspots eingebaut.
